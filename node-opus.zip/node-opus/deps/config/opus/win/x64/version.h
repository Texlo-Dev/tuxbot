#define PACKAGE_VERSION "v1.1-beta"
